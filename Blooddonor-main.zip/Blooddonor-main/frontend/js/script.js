const API_URL = `${window.location.origin}/api`;
// --- AUTHENTICATION ---

// 1. LOGIN LOGIC
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  loginForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    try {
        const response = await fetch(`${API_URL}/login`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ username, password })
        });

        if (response.ok) {
            const data = await response.json();
            // Save Token and Role
            localStorage.setItem("token", data.access_token);
            localStorage.setItem("role", data.role); 
            localStorage.setItem("username", username);
            window.location.href = "dashboard.html";
        } else {
            document.getElementById("error-msg").innerText = "Invalid credentials";
            document.getElementById("error-msg").style.display = "block";
        }
    } catch (err) {
        alert("Backend not connected. Ensure main.py is running.");
    }
  });
}

// 2. SIGNUP LOGIC
const signupForm = document.getElementById("signupForm");
if (signupForm) {
  signupForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const username = document.getElementById("reg-username").value;
    const password = document.getElementById("reg-password").value;

    const response = await fetch(`${API_URL}/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password })
    });

    if (response.ok) {
        alert("Account created! Please login.");
        window.location.href = "index.html";
    } else {
        alert("Error creating account.");
    }
  });
}

// 3. LOGOUT
function logout() {
    localStorage.clear();
    window.location.href = "index.html";
}

// --- DASHBOARD & UI PROTECTION ---

// Run on every page load (except login/signup)
if (!window.location.href.includes("index.html") && !window.location.href.includes("signup.html")) {
    checkAuth();
    loadPageData();
}

function checkAuth() {
    const token = localStorage.getItem("token");
    if (!token) {
        window.location.href = "index.html";
    }
    
    // UI ADJUSTMENTS BASED ON ROLE
    const role = localStorage.getItem("role");
    if (role === "admin") {
        document.querySelectorAll(".admin-only").forEach(el => el.style.display = "");
        // Hide user-only sections if any exist
        document.querySelectorAll("#user-section").forEach(el => el.style.display = "none");
    } else {
        // User is normal
        document.querySelectorAll(".admin-only").forEach(el => el.style.display = "none");
        document.querySelectorAll("#user-section").forEach(el => el.style.display = "block");
    }
}

async function loadPageData() {
    if (document.getElementById("requests-table-body")) {
        loadRequests();
    }
    // NEW: Load inventory if we are on the inventory page
    if (document.getElementById("inventory-table-body")) {
        loadInventory();
    }
}

// --- REQUESTS PAGE LOGIC ---

// 1. SUBMIT REQUEST (User Only)
const requestForm = document.getElementById("requestForm");
if (requestForm) {
    requestForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const payload = {
            requester: document.getElementById("req-name").value,
            bloodGroup: document.getElementById("req-group").value,
            units: parseInt(document.getElementById("req-units").value),
            date: document.getElementById("req-date").value,
            status: "Pending" // Default
        };

        await fetch(`${API_URL}/requests`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        alert("Request Submitted!");
        loadRequests(); // Refresh table
        requestForm.reset();
    });
}

// 2. LOAD REQUESTS (Shared)
async function loadRequests() {
    const res = await fetch(`${API_URL}/requests`);
    const requests = await res.json();
    const tbody = document.getElementById("requests-table-body");
    const role = localStorage.getItem("role");

    tbody.innerHTML = "";
    requests.forEach(req => {
        let actionBtn = "";
        
        // Only Admin sees the "Approve" button for Pending requests
        if (role === "admin" && req.status === "Pending") {
            actionBtn = `<button class="status pending" onclick="approveRequest('${req.id}')">Approve</button>`;
        } else if (role === "admin" && req.status === "Approved") {
            actionBtn = `<span style="color:green">Done</span>`;
        }

        // Check if Admin column is needed
        let adminCol = role === "admin" ? `<td>${actionBtn}</td>` : "";

        const row = `<tr>
            <td>${req.requester}</td>
            <td>${req.bloodGroup}</td>
            <td>${req.units}</td>
            <td>${req.date}</td>
            <td><span class="status ${req.status.toLowerCase()}">${req.status}</span></td>
            ${adminCol}
        </tr>`;
        tbody.innerHTML += row;
    });
    
    // Re-run UI protection to ensure headers match rows
    checkAuth(); 
}

// 3. APPROVE REQUEST (Admin Only)
async function approveRequest(id) {
    if (!confirm("Approve this request? Stock will be deducted.")) return;

    const res = await fetch(`${API_URL}/requests/${id}/approve`, {
        method: "PUT",
         headers: { 
             "Authorization": `Bearer ${localStorage.getItem("token")}`
         }
    });

    if (res.ok) {
        alert("Request Approved & Inventory Updated!");
        loadRequests();
    } else {
        const err = await res.json();
        alert("Error: " + err.detail);
    }
}


// --- INVENTORY PAGE LOGIC ---

// 1. LOAD INVENTORY
async function loadInventory() {
    const res = await fetch(`${API_URL}/inventory`);
    const items = await res.json();
    const tbody = document.getElementById("inventory-table-body");
    
    tbody.innerHTML = "";
    items.forEach(item => {
        const row = `<tr>
            <td>${item.bloodGroup}</td>
            <td>${item.units}</td>
            <td>${item.expiryDate}</td>
            <td><span class="status ${item.status === 'Low Stock' ? 'low' : 'available'}">${item.status}</span></td>
        </tr>`;
        tbody.innerHTML += row;
    });
    
    checkAuth(); // Ensure Admin form is shown/hidden correctly
}

// 2. UPDATE STOCK (Admin Only)
const inventoryForm = document.getElementById("inventoryForm");
if (inventoryForm) {
    inventoryForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        
        const payload = {
            bloodGroup: document.getElementById("inv-group").value,
            units: parseInt(document.getElementById("inv-units").value),
            expiryDate: document.getElementById("inv-expiry").value
        };

        const res = await fetch(`${API_URL}/inventory`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        if (res.ok) {
            alert("Stock Updated Successfully!");
            loadInventory(); // Refresh table
            inventoryForm.reset();
        } else {
            alert("Error updating stock");
        }
    });
}

// --- DONATION LOGIC ---

// 1. Load Data on Page Load
async function loadPageData() {
    if (document.getElementById("requests-table-body")) loadRequests();
    if (document.getElementById("inventory-table-body")) loadInventory();
    if (document.getElementById("donations-table-body")) loadDonations(); // NEW
}

// 2. Load Donations Table
async function loadDonations() {
    const res = await fetch(`${API_URL}/donations`);
    const items = await res.json();
    const tbody = document.getElementById("donations-table-body");
    const role = localStorage.getItem("role");

    tbody.innerHTML = "";
    items.forEach(d => {
        let action = "";
        
        // ADMIN ONLY: Show "Collect" button if Pending
        if (role === "admin" && d.status === "Pending") {
            action = `<button class="status approved" onclick="collectBlood('${d.id}')">Collect Blood</button>`;
        } else if (d.status === "Collected") {
            action = `<span style="color:green; font-weight:bold;">Added to Stock</span>`;
        }

        const adminCol = role === "admin" ? `<td>${action}</td>` : "";

        const row = `<tr>
            <td>${d.donorName}</td>
            <td>${d.bloodGroup}</td>
            <td><span class="status ${d.status === 'Collected' ? 'available' : 'pending'}">${d.status}</span></td>
            ${adminCol}
        </tr>`;
        tbody.innerHTML += row;
    });
    checkAuth(); // Re-apply UI hiding
}

// 3. User Submits Donation Request
const donationForm = document.getElementById("donationForm");
if (donationForm) {
    donationForm.addEventListener("submit", async (e) => {
        e.preventDefault();
        const payload = {
            donorName: document.getElementById("d-name").value,
            bloodGroup: document.getElementById("d-group").value,
            age: parseInt(document.getElementById("d-age").value),
            date: document.getElementById("d-date").value
        };

        await fetch(`${API_URL}/donations`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        alert("Donation Registered! Visit the center for collection.");
        loadDonations();
        donationForm.reset();
    });
}

// 4. Admin Collects Blood
async function collectBlood(id) {
    if(!confirm("Confirm blood collection? Inventory will increase by 1 Unit.")) return;

    const res = await fetch(`${API_URL}/donations/${id}/collect`, { method: "PUT" });
    
    if (res.ok) {
        alert("Blood Collected & Inventory Updated!");
        loadDonations();
    } else {
        alert("Error collecting blood");
    }
}