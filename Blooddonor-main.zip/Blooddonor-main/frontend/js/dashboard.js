const API_BASE = `${window.location.origin}/api`;

async function apiFetch(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  if (!response.ok) {
    const message = await response.text();
    throw new Error(message || "Request failed");
  }

  return response.json();
}

async function loadSummary() {
  try {
    const data = await apiFetch("/summary");
    const totalDonors = document.getElementById("totalDonors");
    const totalUnits = document.getElementById("totalUnits");
    const lowStock = document.getElementById("lowStock");
    const pendingRequests = document.getElementById("pendingRequests");

    if (totalDonors) totalDonors.textContent = data.totalDonors ?? 0;
    if (totalUnits) totalUnits.textContent = data.totalUnits ?? 0;
    if (lowStock) lowStock.textContent = (data.lowStock || []).join(", ") || "None";
    if (pendingRequests) pendingRequests.textContent = data.pendingRequests ?? 0;
  } catch (error) {
    alert("Failed to load dashboard summary.");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadSummary();
});
