const API_BASE = `${window.location.origin}/api`;

async function apiFetch(path, options = {}) {
	const response = await fetch(`${API_BASE}${path}`, {
		headers: { "Content-Type": "application/json" },
		...options,
	});

	if (!response.ok) {
		const message = await response.text();
		throw new Error(message || "Request failed");
	}

	return response.json();
}

function renderRequests(rows) {
	const tbody = document.getElementById("requestTableBody");
	if (!tbody) return;

	tbody.innerHTML = "";
	if (rows.length === 0) {
		const emptyRow = document.createElement("tr");
		emptyRow.innerHTML = "<td colspan=\"5\">No requests yet.</td>";
		tbody.appendChild(emptyRow);
		return;
	}

	rows.forEach((request) => {
		const statusClass = request.status === "Approved" ? "approved" : "pending";
		const row = document.createElement("tr");
		row.innerHTML = `
			<td>${request.requester}</td>
			<td>${request.bloodGroup}</td>
			<td>${request.units}</td>
			<td>${request.date}</td>
			<td><span class="status ${statusClass}">${request.status}</span></td>
		`;
		tbody.appendChild(row);
	});
}

async function loadRequests() {
	try {
		const data = await apiFetch("/requests");
		renderRequests(data);
	} catch (error) {
		alert("Failed to load requests.");
	}
}

document.addEventListener("DOMContentLoaded", () => {
	const requestForm = document.getElementById("requestForm");

	if (requestForm) {
		requestForm.addEventListener("submit", async (event) => {
			event.preventDefault();

			const payload = {
				requester: document.getElementById("requesterName").value.trim(),
				bloodGroup: document.getElementById("requestBloodGroup").value,
				units: Number(document.getElementById("requestUnits").value),
				date: document.getElementById("requestDate").value,
				status: "Pending",
			};

			try {
				await apiFetch("/requests", {
					method: "POST",
					body: JSON.stringify(payload),
				});
				requestForm.reset();
				await loadRequests();
			} catch (error) {
				alert("Failed to submit request.");
			}
		});
	}

	loadRequests();
});
