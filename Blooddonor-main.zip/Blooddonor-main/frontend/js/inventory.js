const API_BASE = `${window.location.origin}/api`;

async function apiFetch(path, options = {}) {
	const response = await fetch(`${API_BASE}${path}`, {
		headers: { "Content-Type": "application/json" },
		...options,
	});

	if (!response.ok) {
		const message = await response.text();
		throw new Error(message || "Request failed");
	}

	return response.json();
}

function renderInventory(rows) {
	const tbody = document.getElementById("inventoryTableBody");
	if (!tbody) return;

	tbody.innerHTML = "";
	if (rows.length === 0) {
		const emptyRow = document.createElement("tr");
		emptyRow.innerHTML = "<td colspan=\"4\">No inventory records yet.</td>";
		tbody.appendChild(emptyRow);
		return;
	}

	rows.forEach((item) => {
		const statusClass = item.status === "Low Stock" ? "low" : "available";
		const row = document.createElement("tr");
		row.innerHTML = `
			<td>${item.bloodGroup}</td>
			<td>${item.units}</td>
			<td>${item.expiryDate}</td>
			<td><span class="status ${statusClass}">${item.status}</span></td>
		`;
		tbody.appendChild(row);
	});
}

async function loadInventory() {
	try {
		const data = await apiFetch("/inventory");
		renderInventory(data);
	} catch (error) {
		alert("Failed to load inventory.");
	}
}

document.addEventListener("DOMContentLoaded", () => {
	loadInventory();
});
