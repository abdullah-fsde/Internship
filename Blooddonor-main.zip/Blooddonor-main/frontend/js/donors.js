const API_BASE = `${window.location.origin}/api`;

async function apiFetch(path, options = {}) {
	const response = await fetch(`${API_BASE}${path}`, {
		headers: { "Content-Type": "application/json" },
		...options,
	});

	if (!response.ok) {
		const message = await response.text();
		throw new Error(message || "Request failed");
	}

	return response.json();
}

function renderDonors(rows) {
	const tbody = document.getElementById("donorTableBody");
	if (!tbody) return;

	tbody.innerHTML = "";
	if (rows.length === 0) {
		const emptyRow = document.createElement("tr");
		emptyRow.innerHTML = "<td colspan=\"5\">No donors yet.</td>";
		tbody.appendChild(emptyRow);
		return;
	}

	rows.forEach((donor) => {
		const row = document.createElement("tr");
		row.innerHTML = `
			<td>${donor.name}</td>
			<td>${donor.age}</td>
			<td>${donor.bloodGroup}</td>
			<td>${donor.contact}</td>
			<td><button class="delete-btn" data-id="${donor.id}">Delete</button></td>
		`;
		tbody.appendChild(row);
	});
}

async function loadDonors() {
	try {
		const data = await apiFetch("/donors");
		renderDonors(data);
	} catch (error) {
		alert("Failed to load donors.");
	}
}

document.addEventListener("DOMContentLoaded", () => {
	const donorForm = document.getElementById("donorForm");
	const tbody = document.getElementById("donorTableBody");

	if (donorForm) {
		donorForm.addEventListener("submit", async (event) => {
			event.preventDefault();

			const payload = {
				name: document.getElementById("donorName").value.trim(),
				age: Number(document.getElementById("donorAge").value),
				bloodGroup: document.getElementById("donorBloodGroup").value,
				contact: document.getElementById("donorContact").value.trim(),
			};

			try {
				await apiFetch("/donors", {
					method: "POST",
					body: JSON.stringify(payload),
				});
				donorForm.reset();
				await loadDonors();
			} catch (error) {
				alert("Failed to add donor.");
			}
		});
	}

	if (tbody) {
		tbody.addEventListener("click", async (event) => {
			const button = event.target.closest("button[data-id]");
			if (!button) return;

			if (!confirm("Are you sure you want to delete this donor?")) {
				return;
			}

			try {
				await apiFetch(`/donors/${button.dataset.id}`, { method: "DELETE" });
				await loadDonors();
			} catch (error) {
				alert("Failed to delete donor.");
			}
		});
	}

	loadDonors();
});
