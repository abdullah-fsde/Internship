const API_BASE = `${window.location.origin}/api`;

async function apiFetch(path, options = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });

  if (!response.ok) {
    const message = await response.text();
    throw new Error(message || "Request failed");
  }

  return response.json();
}

function renderReportTable(rows) {
  const tbody = document.getElementById("reportTableBody");
  if (!tbody) return;

  tbody.innerHTML = "";
  if (rows.length === 0) {
    const emptyRow = document.createElement("tr");
    emptyRow.innerHTML = "<td colspan=\"4\">No report data yet.</td>";
    tbody.appendChild(emptyRow);
    return;
  }

  rows.forEach((row) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${row.bloodGroup}</td>
      <td>${row.totalUnits}</td>
      <td>${row.issuedUnits}</td>
      <td>${row.remainingUnits}</td>
    `;
    tbody.appendChild(tr);
  });
}

async function loadReports() {
  try {
    const data = await apiFetch("/reports");
    const summary = data.summary || {};

    const totalDonors = document.getElementById("reportTotalDonors");
    const totalUnits = document.getElementById("reportTotalUnits");
    const requestsCompleted = document.getElementById("reportRequestsCompleted");
    const pendingRequests = document.getElementById("reportPendingRequests");

    if (totalDonors) totalDonors.textContent = summary.totalDonors ?? 0;
    if (totalUnits) totalUnits.textContent = summary.totalUnits ?? 0;
    if (requestsCompleted) requestsCompleted.textContent = summary.requestsCompleted ?? 0;
    if (pendingRequests) pendingRequests.textContent = summary.pendingRequests ?? 0;

    renderReportTable(data.groups || []);
  } catch (error) {
    alert("Failed to load reports.");
  }
}

document.addEventListener("DOMContentLoaded", () => {
  loadReports();
});
