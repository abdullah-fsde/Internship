import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Depends, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from motor.motor_asyncio import AsyncIOMotorClient
from bson import ObjectId
from pydantic import BaseModel, Field
from passlib.context import CryptContext
from jose import JWTError, jwt

load_dotenv()

# --- CONFIGURATION ---
MONGODB_URI = os.getenv("MONGODB_URI", "")
MONGODB_DB = os.getenv("MONGODB_DB", "bbms")
Admin_user = os.getenv("Bloddy_Donor_Admin")
Admin_pass = os.getenv("Bloddy_Donor_Pass")
SECRET_KEY = os.getenv("SECRET_KEY", "supersecretkey") # Change this in production
ALGORITHM = "HS256"

app = FastAPI(title="BBMS API", version="0.2.0")

# --- SECURITY SETUP ---
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = None # We are using custom JSON login for this demo

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# --- DATABASE CONNECTION ---
if not MONGODB_URI:
    client = None
    db = None
else:
    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB]

def ensure_db():
    if db is None:
        raise HTTPException(status_code=500, detail="MONGODB_URI is not configured")
    return db

# --- MODELS ---

class UserIn(BaseModel):
    username: str
    password: str

class UserOut(BaseModel):
    id: str
    username: str
    role: str

class LoginOut(BaseModel):
    access_token: str
    token_type: str
    role: str
    username: str

class DonorIn(BaseModel):
    name: str = Field(..., min_length=1)
    age: int = Field(..., ge=1)
    bloodGroup: str = Field(..., min_length=1)
    contact: str = Field(..., min_length=1)

class DonorOut(DonorIn):
    id: str

class RequestIn(BaseModel):
    requester: str = Field(..., min_length=1)
    bloodGroup: str = Field(..., min_length=1)
    units: int = Field(..., ge=1)
    date: str = Field(..., min_length=1)
    status: str = Field("Pending", min_length=1)

class RequestOut(RequestIn):
    id: str

class InventoryIn(BaseModel):
    bloodGroup: str = Field(..., min_length=1)
    units: int = Field(..., ge=0)
    expiryDate: str = Field(..., min_length=1)

class InventoryOut(InventoryIn):
    id: str
    status: str




# --- HELPER FUNCTIONS ---

def get_password_hash(password):
    return pwd_context.hash(password)

def verify_password(plain_password, hashed_password):
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=60) # Token lasts 1 hour
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    return encoded_jwt

async def get_current_user_role(token: str):
    """Simple dependency to extract role from token (if needed for stricter security)"""
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload.get("role")
    except JWTError:
        return None

# --- STARTUP EVENT ---
@app.on_event("startup")
async def startup_db_client():
    """Create default Admin user from ENV if not exists"""
    if db is not None:
        # 1. Check if the ENV variables are actually loaded
        if not Admin_user or not Admin_pass:
            print("Warning: Admin ENV variables not set. Skipping admin creation.")
            return

        # 2. Check for the SPECIFIC username from your .env file
        existing_admin = await db.users.find_one({"username": Admin_user})
        
        if not existing_admin:
            print(f"Creating default admin user: {Admin_user}...")
            admin_user = {
                "username": Admin_user,
                "password": get_password_hash(Admin_pass), 
                "role": "admin"
            }
            await db.users.insert_one(admin_user)
        else:
            print(f"Admin user '{Admin_user}' already exists. Skipping creation.")

# --- AUTH ROUTES ---

@app.post("/api/register", response_model=UserOut)
async def register(user: UserIn):
    database = ensure_db()
    existing_user = await database.users.find_one({"username": user.username})
    if existing_user:
        raise HTTPException(status_code=400, detail="Username already taken")
    
    new_user = {
        "username": user.username,
        "password": get_password_hash(user.password),
        "role": "user" # Default role is always User
    }
    result = await database.users.insert_one(new_user)
    return {"id": str(result.inserted_id), "username": user.username, "role": "user"}

@app.post("/api/login", response_model=LoginOut)
async def login(user: UserIn):
    database = ensure_db()
    db_user = await database.users.find_one({"username": user.username})
    
    if not db_user or not verify_password(user.password, db_user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    
    access_token = create_access_token(data={"sub": user.username, "role": db_user["role"]})
    
    return {
        "access_token": access_token, 
        "token_type": "bearer", 
        "role": db_user["role"],
        "username": user.username
    }

# --- DONOR ROUTES ---

@app.get("/api/donors", response_model=list[DonorOut])
async def list_donors():
    database = ensure_db()
    items = []
    async for donor in database.donors.find().sort("_id", -1):
        donor["id"] = str(donor.pop("_id"))
        items.append(donor)
    return items

@app.post("/api/donors", response_model=DonorOut)
async def create_donor(payload: DonorIn):
    database = ensure_db()
    result = await database.donors.insert_one(payload.model_dump())
    return {"id": str(result.inserted_id), **payload.model_dump()}

@app.delete("/api/donors/{donor_id}")
async def delete_donor(donor_id: str):
    database = ensure_db()
    try:
        oid = ObjectId(donor_id)
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid donor id")

    result = await database.donors.delete_one({"_id": oid})
    if result.deleted_count == 0:
        raise HTTPException(status_code=404, detail="Donor not found")
    return {"status": "deleted"}

# --- REQUEST ROUTES ---

@app.get("/api/requests", response_model=list[RequestOut])
async def list_requests():
    database = ensure_db()
    items = []
    async for req in database.requests.find().sort("_id", -1):
        req["id"] = str(req.pop("_id"))
        items.append(req)
    return items

@app.post("/api/requests", response_model=RequestOut)
async def create_request(payload: RequestIn):
    database = ensure_db()
    # Force status to Pending initially
    payload.status = "Pending"
    result = await database.requests.insert_one(payload.model_dump())
    return {"id": str(result.inserted_id), **payload.model_dump()}

@app.put("/api/requests/{request_id}/approve")
async def approve_request(request_id: str):
    """
    1. Check if request exists
    2. Check if enough inventory exists
    3. Deduct inventory
    4. Update request status to 'Approved'
    """
    database = ensure_db()
    
    # 1. Find Request
    try:
        oid = ObjectId(request_id)
    except:
        raise HTTPException(status_code=400, detail="Invalid ID")
        
    req = await database.requests.find_one({"_id": oid})
    if not req:
        raise HTTPException(status_code=404, detail="Request not found")
    
    if req["status"] == "Approved":
        raise HTTPException(status_code=400, detail="Request already approved")

    needed_group = req["bloodGroup"]
    needed_units = req["units"]

    # 2. Check Inventory
    inventory_item = await database.inventory.find_one({"_id": needed_group})
    
    if not inventory_item:
        raise HTTPException(status_code=400, detail=f"No stock found for {needed_group}")
    
    current_units = int(inventory_item.get("units", 0))
    
    if current_units < needed_units:
        raise HTTPException(status_code=400, detail=f"Insufficient stock. Available: {current_units}, Required: {needed_units}")

    # 3. Deduct Inventory
    await database.inventory.update_one(
        {"_id": needed_group},
        {"$inc": {"units": -needed_units}}
    )

    # 4. Update Request Status
    await database.requests.update_one(
        {"_id": oid},
        {"$set": {"status": "Approved"}}
    )

    return {"status": "approved", "message": f"Approved {needed_units} units of {needed_group}"}

# --- INVENTORY ROUTES ---

@app.get("/api/inventory", response_model=list[InventoryOut])
async def list_inventory():
    database = ensure_db()
    items = []
    async for item in database.inventory.find().sort("bloodGroup", 1):
        item["id"] = str(item.pop("_id"))
        units = int(item.get("units", 0))
        item["status"] = "Low Stock" if units < 5 else "Available"
        items.append(item)
    return items

@app.post("/api/inventory", response_model=InventoryOut)
async def upsert_inventory(payload: InventoryIn):
    database = ensure_db()
    # Use bloodGroup as the _id to ensure uniqueness per group
    await database.inventory.update_one(
        {"_id": payload.bloodGroup},
        {"$set": {**payload.model_dump(), "bloodGroup": payload.bloodGroup}},
        upsert=True,
    )
    item = payload.model_dump()
    item["id"] = payload.bloodGroup
    item["status"] = "Low Stock" if payload.units < 5 else "Available"
    return item

# --- REPORTS & SUMMARY ---

@app.get("/api/summary")
async def summary():
    database = ensure_db()
    donor_count = await database.donors.count_documents({})
    pending_count = await database.requests.count_documents({"status": "Pending"})
    total_units = 0
    low_stock = []

    async for item in database.inventory.find():
        units = int(item.get("units", 0))
        total_units += units
        if units < 5:
            low_stock.append(item.get("bloodGroup", ""))

    return {
        "totalDonors": donor_count,
        "totalUnits": total_units,
        "lowStock": [group for group in low_stock if group],
        "pendingRequests": pending_count,
    }

@app.get("/api/reports")
async def reports():
    database = ensure_db()
    groups = []
    async for item in database.inventory.find().sort("bloodGroup", 1):
        groups.append(
            {
                "bloodGroup": item.get("bloodGroup", ""),
                "totalUnits": int(item.get("units", 0)),
                "issuedUnits": 0, # In a real full app, you'd calculate this from history
                "remainingUnits": int(item.get("units", 0)),
            }
        )

    donor_count = await database.donors.count_documents({})
    total_units = sum(row["totalUnits"] for row in groups)
    completed_requests = await database.requests.count_documents({"status": "Approved"})
    pending_requests = await database.requests.count_documents({"status": "Pending"})

    return {
        "summary": {
            "totalDonors": donor_count,
            "totalUnits": total_units,
            "requestsCompleted": completed_requests,
            "pendingRequests": pending_requests,
        },
        "groups": groups,
    }

# Add this Model near the top with others
class DonationIn(BaseModel):
    donorName: str
    bloodGroup: str
    age: int
    date: str
    status: str = "Pending" # Pending, Collected, Rejected

class DonationOut(DonationIn):
    id: str

# --- DONATION ROUTES ---

@app.get("/api/donations", response_model=list[DonationOut])
async def list_donations():
    database = ensure_db()
    items = []
    async for d in database.donations.find().sort("_id", -1):
        d["id"] = str(d.pop("_id"))
        items.append(d)
    return items

@app.post("/api/donations", response_model=DonationOut)
async def create_donation(payload: DonationIn):
    database = ensure_db()
    payload.status = "Pending"
    result = await database.donations.insert_one(payload.model_dump())
    return {"id": str(result.inserted_id), **payload.model_dump()}

@app.put("/api/donations/{id}/collect")
async def collect_donation(id: str):
    """
    Admin clicks 'Collected':
    1. Update Donation Status -> 'Collected'
    2. Add +1 to Inventory for that Blood Group
    """
    database = ensure_db()
    try:
        oid = ObjectId(id)
    except:
        raise HTTPException(status_code=400, detail="Invalid ID")

    # 1. Get Donation Info
    donation = await database.donations.find_one({"_id": oid})
    if not donation:
        raise HTTPException(status_code=404, detail="Donation not found")
    
    if donation["status"] == "Collected":
        raise HTTPException(status_code=400, detail="Already collected")

    # 2. Update Inventory (+1 Unit)
    group = donation["bloodGroup"]
    await database.inventory.update_one(
        {"_id": group},
        {"$inc": {"units": 1}, "$setOnInsert": {"bloodGroup": group, "expiryDate": "2026-12-31"}}, # Default expiry if new
        upsert=True
    )

    # 3. Mark Donation as Collected
    await database.donations.update_one(
        {"_id": oid},
        {"$set": {"status": "Collected"}}
    )

    return {"status": "success", "message": "Blood collected and added to inventory"}


# --- STATIC FILES ---
frontend_dir = Path(__file__).resolve().parents[1] / "frontend"


if frontend_dir.exists():
    app.mount("/", StaticFiles(directory=frontend_dir, html=True), name="frontend")