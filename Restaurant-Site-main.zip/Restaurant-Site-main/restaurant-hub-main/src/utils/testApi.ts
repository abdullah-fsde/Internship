import apiService from '@/services/api';

export const testApiConnection = async () => {
  try {
    console.log('Testing API connection...');
    const health = await apiService.healthCheck();
    console.log('✅ API Health Check:', health);
    
    const menuItems = await apiService.getMenuItems();
    console.log('✅ Menu Items:', menuItems);
    
    const categories = await apiService.getCategories();
    console.log('✅ Categories:', categories);
    
    return true;
  } catch (error) {
    console.error('❌ API Connection Failed:', error);
    return false;
  }
};

// Auto-test on development
if (import.meta.env.DEV) {
  setTimeout(() => {
    testApiConnection();
  }, 1000);
}