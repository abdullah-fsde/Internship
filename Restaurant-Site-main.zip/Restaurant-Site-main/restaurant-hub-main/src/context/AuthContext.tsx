import { createContext, useContext, ReactNode, useEffect, useState } from "react";
import apiService from "@/services/api";

export interface User {
  _id: string;
  name: string;
  email: string;
  role: "admin" | "user";
  createdAt: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  loading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Check for existing token on app load
  useEffect(() => {
    const checkAuthStatus = async () => {
      const token = localStorage.getItem('backend_token');
      if (token) {
        try {
          // Decode JWT to get user info (simple decode, not verification)
          const payload = JSON.parse(atob(token.split('.')[1]));
          
          // Check if token is expired
          if (payload.exp * 1000 < Date.now()) {
            console.log('Token expired, clearing...');
            localStorage.removeItem('backend_token');
            apiService.logout();
            setLoading(false);
            return;
          }

          // Validate token with backend
          try {
            // Make a simple API call to verify token is still valid
            await apiService.healthCheck();
            
            setUser({
              _id: payload.id,
              name: payload.name || 'User',
              email: payload.email,
              role: payload.role,
              createdAt: new Date().toISOString(),
            });
          } catch (error) {
            console.log('Token validation failed, clearing...');
            localStorage.removeItem('backend_token');
            apiService.logout();
          }
        } catch (error) {
          console.log('Token parsing failed, clearing...');
          // Token is invalid, clear it
          localStorage.removeItem('backend_token');
          apiService.logout();
        }
      }
      setLoading(false);
    };

    checkAuthStatus();
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const response = await apiService.login(email, password);
      
      const userData = {
        _id: response.user.id,
        name: response.user.name,
        email: response.user.email,
        role: response.user.role,
        createdAt: new Date().toISOString(),
      };
      
      setUser(userData);
      return true;
    } catch (error) {
      console.error('Login failed:', error);
      return false;
    }
  };

  const register = async (name: string, email: string, password: string): Promise<boolean> => {
    try {
      const response = await apiService.register(name, email, password);
      setUser({
        _id: response.user.id,
        name: response.user.name,
        email: response.user.email,
        role: response.user.role,
        createdAt: new Date().toISOString(),
      });
      return true;
    } catch (error) {
      console.error('Registration failed:', error);
      return false;
    }
  };

  const logout = () => {
    apiService.logout();
    setUser(null);
  };

  const value = {
    user,
    isAuthenticated: !!user,
    isAdmin: user?.role === "admin",
    loading,
    login,
    register,
    logout,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}