import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { MenuItem } from "@/data/mockData";
import apiService from "@/services/api";

interface MenuContextType {
    items: MenuItem[];
    loading: boolean;
    error: string | null;
    addMenuItem: (item: Omit<MenuItem, '_id'>) => Promise<void>;
    updateMenuItem: (item: MenuItem) => Promise<void>;
    deleteMenuItem: (id: string) => Promise<void>;
    toggleAvailability: (id: string) => Promise<void>;
    refetchItems: () => Promise<void>;
}

const MenuContext = createContext<MenuContextType | undefined>(undefined);

export function MenuProvider({ children }: { children: ReactNode }) {
    const [items, setItems] = useState<MenuItem[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchMenuItems = async () => {
        try {
            setLoading(true);
            setError(null);
            const response = await apiService.getMenuItems();
            // Handle both paginated and direct array responses
            const menuItems = response.items || response;
            setItems(menuItems);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to fetch menu items');
            console.error('Failed to fetch menu items:', err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchMenuItems();
    }, []);

    const addMenuItem = async (itemData: Omit<MenuItem, '_id'>) => {
        try {
            const newItem = await apiService.createMenuItem(itemData);
            setItems((prev) => [...prev, newItem]);
        } catch (error) {
            console.error('Failed to add menu item:', error);
            throw error;
        }
    };

    const updateMenuItem = async (updatedItem: MenuItem) => {
        try {
            const updated = await apiService.updateMenuItem(updatedItem._id, updatedItem);
            setItems((prev) =>
                prev.map((item) => (item._id === updatedItem._id ? updated : item))
            );
        } catch (error) {
            console.error('Failed to update menu item:', error);
            throw error;
        }
    };

    const deleteMenuItem = async (id: string) => {
        try {
            await apiService.deleteMenuItem(id);
            setItems((prev) => prev.filter((item) => item._id !== id));
        } catch (error) {
            console.error('Failed to delete menu item:', error);
            throw error;
        }
    };

    const toggleAvailability = async (id: string) => {
        try {
            const updated = await apiService.toggleItemAvailability(id);
            setItems((prev) =>
                prev.map((item) =>
                    item._id === id ? { ...item, available: updated.available } : item
                )
            );
        } catch (error) {
            console.error('Failed to toggle availability:', error);
            throw error;
        }
    };

    const refetchItems = async () => {
        await fetchMenuItems();
    };

    return (
        <MenuContext.Provider
            value={{
                items,
                loading,
                error,
                addMenuItem,
                updateMenuItem,
                deleteMenuItem,
                toggleAvailability,
                refetchItems,
            }}
        >
            {children}
        </MenuContext.Provider>
    );
}

export function useMenu() {
    const context = useContext(MenuContext);
    if (context === undefined) {
        throw new Error("useMenu must be used within a MenuProvider");
    }
    return context;
}
