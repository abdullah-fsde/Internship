import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { Order } from "@/data/mockData";
import apiService from "@/services/api";

interface OrderContextType {
    orders: Order[];
    loading: boolean;
    error: string | null;
    updateOrderStatus: (orderId: string, status: Order["status"]) => Promise<void>;
    createOrder: (orderData: any) => Promise<Order>;
    refetchOrders: () => Promise<void>;
}

const OrderContext = createContext<OrderContextType | undefined>(undefined);

export function OrderProvider({ children }: { children: ReactNode }) {
    const [orders, setOrders] = useState<Order[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const fetchOrders = async () => {
        try {
            setLoading(true);
            setError(null);
            const response = await apiService.getOrders();
            
            // Handle both paginated and direct array responses
            const orderData = response.orders || response;
            setOrders(orderData);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Failed to fetch orders');
            console.error('Failed to fetch orders:', err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchOrders();
    }, []);

    const updateOrderStatus = async (orderId: string, status: Order["status"]) => {
        try {
            await apiService.updateOrderStatus(orderId, status);
            setOrders((prev) =>
                prev.map((order) =>
                    order._id === orderId ? { ...order, status } : order
                )
            );
        } catch (error) {
            console.error('Failed to update order status:', error);
            throw error;
        }
    };

    const createOrder = async (orderData: any): Promise<Order> => {
        try {
            const newOrder = await apiService.createOrder(orderData);
            setOrders((prev) => [newOrder, ...prev]);
            return newOrder;
        } catch (error) {
            console.error('Failed to create order:', error);
            throw error;
        }
    };

    const refetchOrders = async () => {
        await fetchOrders();
    };

    return (
        <OrderContext.Provider value={{ 
            orders, 
            loading, 
            error, 
            updateOrderStatus, 
            createOrder, 
            refetchOrders 
        }}>
            {children}
        </OrderContext.Provider>
    );
}

export function useOrders() {
    const context = useContext(OrderContext);
    if (context === undefined) {
        throw new Error("useOrders must be used within a OrderProvider");
    }
    return context;
}
