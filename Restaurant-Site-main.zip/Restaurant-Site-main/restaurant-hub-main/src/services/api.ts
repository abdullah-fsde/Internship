const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:5000/api';

class ApiService {
  private baseURL: string;
  private token: string | null;

  constructor() {
    this.baseURL = API_BASE_URL;
    this.token = localStorage.getItem('backend_token');
  }

  setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem('backend_token', token);
    } else {
      localStorage.removeItem('backend_token');
    }
  }

  private async request(endpoint: string, options: RequestInit = {}) {
    const url = `${this.baseURL}${endpoint}`;
    const config: RequestInit = {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    };

    if (this.token) {
      config.headers = {
        ...config.headers,
        Authorization: `Bearer ${this.token}`,
      };
    }

    try {
      const response = await fetch(url, config);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'API request failed');
      }

      return data;
    } catch (error) {
      console.error('API Error:', error);
      throw error;
    }
  }

  // Legacy auth methods
  async login(email: string, password: string) {
    const data = await this.request('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
    });
    this.setToken(data.token);
    return data;
  }

  async register(name: string, email: string, password: string) {
    const data = await this.request('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ name, email, password }),
    });
    this.setToken(data.token);
    return data;
  }
  async getMenuItems(filters: Record<string, any> = {}) {
    const queryParams = new URLSearchParams();
    Object.keys(filters).forEach(key => {
      if (filters[key] !== undefined && filters[key] !== '') {
        queryParams.append(key, filters[key]);
      }
    });
    
    const endpoint = queryParams.toString() ? `/menu/items?${queryParams}` : '/menu/items';
    return this.request(endpoint);
  }

  async getMenuItem(id: string) {
    return this.request(`/menu/items/${id}`);
  }

  async getCategories() {
    return this.request('/menu/categories');
  }

  async createMenuItem(itemData: any) {
    return this.request('/menu/items', {
      method: 'POST',
      body: JSON.stringify(itemData),
    });
  }

  async updateMenuItem(id: string, itemData: any) {
    return this.request(`/menu/items/${id}`, {
      method: 'PUT',
      body: JSON.stringify(itemData),
    });
  }

  async deleteMenuItem(id: string) {
    return this.request(`/menu/items/${id}`, {
      method: 'DELETE',
    });
  }

  async toggleItemAvailability(id: string) {
    return this.request(`/menu/items/${id}/availability`, {
      method: 'PATCH',
    });
  }

  // Order methods
  async createOrder(orderData: any) {
    return this.request('/orders', {
      method: 'POST',
      body: JSON.stringify(orderData),
    });
  }

  async getOrders(filters: Record<string, any> = {}) {
    const queryParams = new URLSearchParams();
    
    // Set a high limit to get all orders for admin
    queryParams.append('limit', '100');
    
    Object.keys(filters).forEach(key => {
      if (filters[key] !== undefined && filters[key] !== '') {
        queryParams.append(key, filters[key]);
      }
    });
    
    const endpoint = queryParams.toString() ? `/orders?${queryParams}` : '/orders?limit=100';
    return this.request(endpoint);
  }

  async getOrder(id: string) {
    return this.request(`/orders/${id}`);
  }

  async updateOrderStatus(id: string, status: string) {
    return this.request(`/orders/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    });
  }

  // User methods
  async getUsers() {
    return this.request('/users');
  }

  async getUser(id: string) {
    return this.request(`/users/${id}`);
  }

  async updateUser(id: string, userData: any) {
    return this.request(`/users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(userData),
    });
  }

  async updateProfile(userData: any) {
    // For now, just return success - in a real app, this would update the user profile
    return Promise.resolve({ success: true, user: userData });
  }

  // Stats methods
  async getDashboardStats() {
    return this.request('/stats/overview');
  }

  async getRevenueStats(filters: Record<string, any> = {}) {
    const queryParams = new URLSearchParams();
    Object.keys(filters).forEach(key => {
      if (filters[key] !== undefined && filters[key] !== '') {
        queryParams.append(key, filters[key]);
      }
    });
    
    const endpoint = queryParams.toString() ? `/stats/revenue?${queryParams}` : '/stats/revenue';
    return this.request(endpoint);
  }

  async getPopularItems(limit = 10) {
    return this.request(`/stats/menu/popular?limit=${limit}`);
  }

  async getRecentOrders(limit = 10) {
    return this.request(`/stats/orders/recent?limit=${limit}`);
  }

  // Menu methods

  logout() {
    this.setToken(null);
  }

  // Health check
  async healthCheck() {
    return this.request('/health');
  }
}

export default new ApiService();