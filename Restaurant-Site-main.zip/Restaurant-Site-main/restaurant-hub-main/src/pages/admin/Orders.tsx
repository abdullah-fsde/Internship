import { useOrders } from "@/context/OrderContext";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";

const statusOptions = ["pending", "preparing", "ready", "delivered", "cancelled"];

const getStatusColor = (status: string) => {
  const styles: Record<string, string> = {
    pending: "bg-yellow-100 text-yellow-800 border-yellow-200",
    preparing: "bg-blue-100 text-blue-800 border-blue-200",
    ready: "bg-green-100 text-green-800 border-green-200",
    delivered: "bg-gray-100 text-gray-800 border-gray-200",
    cancelled: "bg-red-100 text-red-800 border-red-200",
  };
  return styles[status] || "bg-gray-100 text-gray-800 border-gray-200";
};

const Orders = () => {
  const { orders: orderList, updateOrderStatus } = useOrders();

  const updateStatus = async (orderId: string, newStatus: string) => {
    try {
      await updateOrderStatus(orderId, newStatus as any);
      toast({
        title: "Order Updated",
        description: `Order #${orderId} status changed to ${newStatus}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Update failed",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-medium">Orders</h1>
        <p className="text-muted-foreground">
          Manage and track all restaurant orders
        </p>
      </div>

      {/* Desktop Table */}
      <div className="bg-card rounded-xl border border-border hidden md:block">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-border">
                <th className="text-left text-sm font-medium text-muted-foreground px-5 py-4">
                  Order ID
                </th>
                <th className="text-left text-sm font-medium text-muted-foreground px-5 py-4">
                  Customer
                </th>
                <th className="text-left text-sm font-medium text-muted-foreground px-5 py-4">
                  Items
                </th>
                <th className="text-left text-sm font-medium text-muted-foreground px-5 py-4">
                  Total
                </th>
                <th className="text-left text-sm font-medium text-muted-foreground px-5 py-4">
                  Date
                </th>
                <th className="text-left text-sm font-medium text-muted-foreground px-5 py-4">
                  Status
                </th>
              </tr>
            </thead>
            <tbody>
              {orderList.map((order) => (
                <tr
                  key={order._id}
                  className="border-b border-border last:border-0"
                >
                  <td className="px-5 py-4 text-sm font-medium">#{order._id.slice(-6)}</td>
                  <td className="px-5 py-4 text-sm">{order.customerName}</td>
                  <td className="px-5 py-4 text-sm text-muted-foreground">
                    {order.items && order.items.length > 0 
                      ? order.items.map((i) => `${i.name} (${i.quantity})`).join(", ")
                      : "No items"
                    }
                  </td>
                  <td className="px-5 py-4 text-sm font-medium">
                    ₹{(order.totalAmount / 100).toFixed(2)}
                  </td>
                  <td className="px-5 py-4 text-sm text-muted-foreground">
                    {new Date(order.createdAt).toLocaleDateString()}
                  </td>
                  <td className="px-5 py-4">
                    <Select
                      value={order.status}
                      onValueChange={(value) => updateStatus(order._id, value)}
                    >
                      <SelectTrigger className={`w-32 capitalize ${getStatusColor(order.status)}`}>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {statusOptions.map((status) => (
                          <SelectItem key={status} value={status}>
                            <span className="capitalize">{status}</span>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Mobile Cards */}
      <div className="md:hidden space-y-4">
        {orderList.map((order) => (
          <div
            key={order._id}
            className="bg-card rounded-xl border border-border p-4 space-y-3"
          >
            <div className="flex items-center justify-between">
              <span className="font-medium">Order #{order._id.slice(-6)}</span>
              <Select
                value={order.status}
                onValueChange={(value) => updateStatus(order._id, value)}
              >
                <SelectTrigger className={`w-28 capitalize ${getStatusColor(order.status)}`}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {statusOptions.map((status) => (
                    <SelectItem key={status} value={status}>
                      <span className="capitalize">{status}</span>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="text-sm">
              <span className="text-muted-foreground">Customer: </span>
              {order.customerName}
            </div>
            <div className="text-sm">
              <span className="text-muted-foreground">Items: </span>
              {order.items && order.items.length > 0 
                ? order.items.map((i) => `${i.name} (${i.quantity})`).join(", ")
                : "No items"
              }
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">
                {new Date(order.createdAt).toLocaleDateString()}
              </span>
              <span className="font-semibold text-primary">
                ₹{(order.totalAmount / 100).toFixed(2)}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Orders;