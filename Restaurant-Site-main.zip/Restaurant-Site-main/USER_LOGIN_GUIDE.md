# 🔐 Quick Login Guide

## 🚀 Test Credentials

### 🛡️ **Admin Access**
```
Email: admin@restaurant.com
Password: admin123
URL: http://localhost:8080/admin/login
Features: Full admin dashboard, menu management, order management
```

### 👤 **User Access**
```
Email: sarah@example.com
Password: user123
URL: http://localhost:8080/login
Features: Menu browsing, ordering, profile management

Email: user@restaurant.com
Password: user123
Features: Menu browsing, ordering, profile management
```

## 🎯 **Quick Test Flow**

### **User Test (2 minutes)**
1. Visit: http://localhost:8080/login
2. Login: `sarah@example.com` / `user123`
3. Browse menu → Add items to cart → Checkout
4. Check profile page

### **Admin Test (2 minutes)**
1. Visit: http://localhost:8080/admin/login
2. Login: `admin@restaurant.com` / `admin123`
3. Check dashboard stats → Manage orders → Add menu item

## 🔧 **Troubleshooting**

### **Can't Login?**
- Ensure both backend (port 5000) and frontend (port 8080) are running
- Clear browser localStorage and try again
- Check browser console for errors

### **No Data Showing?**
- Run database seeder: `cd database-seeder && node seed.js`
- Check MongoDB connection in .env files

---

**For complete setup instructions, see the main [README.md](README.md)**