# 🍽️ Restaurant Management System - Quick Start

## 🚀 Setup (5 minutes)

**Prerequisites:** Node.js + MongoDB

```bash
# 1. Clone & Install
git clone <repo-url>
cd Restaurant-Site

# 2. Backend Setup
cd backend_Server
npm install
cp .env.example .env
# Edit .env: Add your MongoDB connection string
npm start

# 3. Database Setup (new terminal)
cd database-seeder
npm install
cp .env.example .env
# Edit .env: Same MongoDB connection
node seed.js

# 4. Frontend Setup (new terminal)
cd restaurant-hub-main
npm install
cp .env.example .env
# No editing needed - uses localhost:5000 by default
npm run dev
```

## 🔑 Test Login

**Admin:** http://localhost:8080/admin/login
- Email: `admin@restaurant.com`
- Password: `admin123`

**User:** http://localhost:8080/login
- Email: `sarah@example.com`
- Password: `user123`

## ✨ Features
- 👤 User: Browse menu, order food, track orders
- 🛡️ Admin: Manage menu, orders, users, dashboard

**URLs:**
- Frontend: http://localhost:8080
- Backend: http://localhost:5000

**No API keys needed!** Pure email/password authentication. 🎉