import mongoose from 'mongoose';

const menuItemSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    description: {
      type: String,
      required: true,
    },
    price: {
      type: Number,
      required: true,
      min: 0,
    },
    category: {
      type: String,
      required: true,
      enum: ['Starters', 'Mains', 'Desserts', 'Beverages'],
    },
    image: {
      type: String,
      default: '/placeholder.svg',
    },
    available: {
      type: Boolean,
      default: true,
    },
    featured: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

// Use fixed collection name
export default mongoose.model('MenuItem', menuItemSchema, 'menuitems');
