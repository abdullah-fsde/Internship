import express from 'express';
import authRoutes from './auth.js';
import menuRoutes from './menu.js';
import orderRoutes from './orders.js';
import userRoutes from './users.js';
import statsRoutes from './stats.js';

const router = express.Router();

// API Index - All available endpoints
router.get('/', (req, res) => {
  const apiIndex = {
    title: 'Restaurant Hub API',
    version: '1.0.0',
    description: 'Complete API for Restaurant Management System',
    baseUrl: `${req.protocol}://${req.get('host')}/api`,
    endpoints: {
      authentication: {
        description: 'User and admin authentication endpoints',
        baseRoute: '/auth',
        endpoints: [
          {
            method: 'POST',
            path: '/auth/register',
            description: 'Register a new user',
            auth: false,
            body: {
              name: 'string (required)',
              email: 'string (required)',
              password: 'string (required, min 6 chars)'
            },
            response: {
              token: 'JWT token',
              user: 'User object without password'
            }
          },
          {
            method: 'POST',
            path: '/auth/login',
            description: 'Login user',
            auth: false,
            body: {
              email: 'string (required)',
              password: 'string (required)'
            },
            response: {
              token: 'JWT token',
              user: 'User object without password'
            }
          },
          {
            method: 'POST',
            path: '/auth/admin/register',
            description: 'Register a new admin',
            auth: false,
            body: {
              name: 'string (required)',
              email: 'string (required)',
              password: 'string (required, min 6 chars)',
              adminSecret: 'string (required)'
            },
            response: {
              token: 'JWT token',
              user: 'Admin user object'
            }
          },
          {
            method: 'POST',
            path: '/auth/admin/login',
            description: 'Login admin',
            auth: false,
            body: {
              email: 'string (required)',
              password: 'string (required)'
            },
            response: {
              token: 'JWT token',
              user: 'Admin user object'
            }
          }
        ]
      },
      menu: {
        description: 'Menu items management',
        baseRoute: '/menu',
        endpoints: [
          {
            method: 'GET',
            path: '/menu/items',
            description: 'Get all menu items',
            auth: false,
            queryParams: {
              category: 'string (optional) - Starters, Mains, Desserts, Beverages',
              featured: 'boolean (optional) - true/false',
              available: 'boolean (optional) - true/false',
              search: 'string (optional) - text search in name/description'
            },
            response: 'Array of menu items'
          },
          {
            method: 'GET',
            path: '/menu/items/:id',
            description: 'Get single menu item',
            auth: false,
            params: {
              id: 'string (required) - Menu item ID'
            },
            response: 'Menu item object'
          },
          {
            method: 'GET',
            path: '/menu/categories',
            description: 'Get all categories',
            auth: false,
            response: 'Array of category strings'
          },
          {
            method: 'POST',
            path: '/menu/items',
            description: 'Create new menu item',
            auth: 'Admin only',
            body: {
              name: 'string (required)',
              description: 'string (required)',
              price: 'number (required)',
              category: 'string (required)',
              image: 'string (optional)',
              available: 'boolean (optional, default: true)',
              featured: 'boolean (optional, default: false)'
            },
            response: 'Created menu item'
          },
          {
            method: 'PUT',
            path: '/menu/items/:id',
            description: 'Update menu item',
            auth: 'Admin only',
            params: {
              id: 'string (required) - Menu item ID'
            },
            body: 'Any menu item fields to update',
            response: 'Updated menu item'
          },
          {
            method: 'DELETE',
            path: '/menu/items/:id',
            description: 'Delete menu item',
            auth: 'Admin only',
            params: {
              id: 'string (required) - Menu item ID'
            },
            response: 'Success message'
          },
          {
            method: 'PATCH',
            path: '/menu/items/:id/availability',
            description: 'Toggle item availability',
            auth: 'Admin only',
            params: {
              id: 'string (required) - Menu item ID'
            },
            response: 'Updated menu item'
          }
        ]
      },
      orders: {
        description: 'Order management',
        baseRoute: '/orders',
        endpoints: [
          {
            method: 'POST',
            path: '/orders',
            description: 'Create new order',
            auth: 'Required',
            body: {
              items: 'array (required) - Array of order items',
              totalAmount: 'number (required)',
              customerName: 'string (required)',
              customerEmail: 'string (required)',
              customerPhone: 'string (required)',
              deliveryAddress: 'object (required) - {street, city, zip}'
            },
            response: 'Created order'
          },
          {
            method: 'GET',
            path: '/orders',
            description: 'Get orders (user: own orders, admin: all orders)',
            auth: 'Required',
            queryParams: {
              status: 'string (optional) - pending, preparing, ready, delivered, cancelled',
              limit: 'number (optional) - limit results',
              page: 'number (optional) - page number'
            },
            response: 'Array of orders'
          },
          {
            method: 'GET',
            path: '/orders/:id',
            description: 'Get single order',
            auth: 'Required',
            params: {
              id: 'string (required) - Order ID'
            },
            response: 'Order object'
          },
          {
            method: 'PATCH',
            path: '/orders/:id/status',
            description: 'Update order status',
            auth: 'Admin only',
            params: {
              id: 'string (required) - Order ID'
            },
            body: {
              status: 'string (required) - pending, preparing, ready, delivered, cancelled'
            },
            response: 'Updated order'
          }
        ]
      },
      users: {
        description: 'User management',
        baseRoute: '/users',
        endpoints: [
          {
            method: 'GET',
            path: '/users',
            description: 'Get all users',
            auth: 'Admin only',
            queryParams: {
              role: 'string (optional) - user, admin',
              limit: 'number (optional) - limit results',
              page: 'number (optional) - page number'
            },
            response: 'Array of users (without passwords)'
          },
          {
            method: 'GET',
            path: '/users/:id',
            description: 'Get user profile',
            auth: 'Required (own profile or admin)',
            params: {
              id: 'string (required) - User ID'
            },
            response: 'User object (without password)'
          },
          {
            method: 'PUT',
            path: '/users/:id',
            description: 'Update user profile',
            auth: 'Required (own profile or admin)',
            params: {
              id: 'string (required) - User ID'
            },
            body: {
              name: 'string (optional)',
              avatar: 'string (optional)'
            },
            response: 'Updated user object'
          }
        ]
      },
      statistics: {
        description: 'Admin statistics and analytics',
        baseRoute: '/stats',
        endpoints: [
          {
            method: 'GET',
            path: '/stats/overview',
            description: 'Get dashboard overview stats',
            auth: 'Admin only',
            response: {
              totalRevenue: 'number',
              totalOrders: 'number',
              totalUsers: 'number',
              totalMenuItems: 'number',
              recentOrders: 'array',
              popularItems: 'array'
            }
          },
          {
            method: 'GET',
            path: '/stats/revenue',
            description: 'Get revenue statistics',
            auth: 'Admin only',
            queryParams: {
              period: 'string (optional) - daily, weekly, monthly, yearly',
              startDate: 'string (optional) - ISO date',
              endDate: 'string (optional) - ISO date'
            },
            response: 'Revenue data'
          },
          {
            method: 'GET',
            path: '/stats/orders/count',
            description: 'Get orders count',
            auth: 'Admin only',
            queryParams: {
              status: 'string (optional) - filter by status',
              period: 'string (optional) - today, week, month'
            },
            response: 'Orders count'
          },
          {
            method: 'GET',
            path: '/stats/orders/recent',
            description: 'Get recent orders',
            auth: 'Admin only',
            queryParams: {
              limit: 'number (optional, default: 10)'
            },
            response: 'Array of recent orders'
          },
          {
            method: 'GET',
            path: '/stats/menu/popular',
            description: 'Get popular menu items',
            auth: 'Admin only',
            queryParams: {
              limit: 'number (optional, default: 10)'
            },
            response: 'Array of popular items with order counts'
          },
          {
            method: 'GET',
            path: '/stats/users/count',
            description: 'Get users count',
            auth: 'Admin only',
            queryParams: {
              role: 'string (optional) - user, admin'
            },
            response: 'Users count'
          }
        ]
      }
    },
    dataModels: {
      User: {
        _id: 'ObjectId',
        name: 'String',
        email: 'String (unique)',
        password: 'String (hashed)',
        role: 'String (user|admin)',
        avatar: 'String',
        createdAt: 'Date',
        updatedAt: 'Date'
      },
      MenuItem: {
        _id: 'ObjectId',
        name: 'String',
        description: 'String',
        price: 'Number',
        category: 'String (Starters|Mains|Desserts|Beverages)',
        image: 'String',
        available: 'Boolean',
        featured: 'Boolean',
        createdAt: 'Date',
        updatedAt: 'Date'
      },
      Order: {
        _id: 'ObjectId',
        userId: 'ObjectId (ref: User)',
        customerName: 'String',
        customerEmail: 'String',
        customerPhone: 'String',
        deliveryAddress: {
          street: 'String',
          city: 'String',
          zip: 'String'
        },
        items: [{
          itemId: 'ObjectId (ref: MenuItem)',
          name: 'String',
          quantity: 'Number',
          price: 'Number'
        }],
        totalAmount: 'Number',
        status: 'String (pending|preparing|ready|delivered|cancelled)',
        createdAt: 'Date',
        updatedAt: 'Date'
      }
    },
    authentication: {
      type: 'JWT Bearer Token',
      header: 'Authorization: Bearer <token>',
      expiration: '7 days',
      note: 'Include token in Authorization header for protected endpoints'
    },
    errorCodes: {
      200: 'Success',
      201: 'Created',
      400: 'Bad Request - Invalid input',
      401: 'Unauthorized - Missing or invalid token',
      403: 'Forbidden - Insufficient permissions',
      404: 'Not Found - Resource not found',
      409: 'Conflict - Resource already exists',
      500: 'Internal Server Error'
    },
    examples: {
      authHeader: 'Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...',
      createOrder: {
        items: [
          {
            itemId: '507f1f77bcf86cd799439011',
            name: 'Truffle Risotto',
            quantity: 2,
            price: 2500
          }
        ],
        totalAmount: 5000,
        customerName: 'John Doe',
        customerEmail: 'john@example.com',
        customerPhone: '9876543210',
        deliveryAddress: {
          street: '123 Main St',
          city: 'New York',
          zip: '10001'
        }
      }
    }
  };

  res.json(apiIndex);
});

// Mount route modules
router.use('/auth', authRoutes);
router.use('/menu', menuRoutes);
router.use('/orders', orderRoutes);
router.use('/users', userRoutes);
router.use('/stats', statsRoutes);

// Health check endpoint
router.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    environment: process.env.NODE_ENV || 'development',
    database: 'Connected'
  });
});

export default router;