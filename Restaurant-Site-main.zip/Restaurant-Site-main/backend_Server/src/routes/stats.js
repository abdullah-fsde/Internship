import express from 'express';
import Order from '../models/Order.js';
import MenuItem from '../models/MenuItem.js';
import User from '../models/User.js';
import { protect, adminOnly } from '../middleware/auth.js';

const router = express.Router();

// GET dashboard overview stats (admin only)
router.get('/overview', protect, adminOnly, async (req, res) => {
  try {
    // Get total revenue (excluding cancelled orders)
    const revenueResult = await Order.aggregate([
      { $match: { status: { $ne: 'cancelled' } } },
      { $group: { _id: null, total: { $sum: '$totalAmount' } } },
    ]);
    const totalRevenue = revenueResult[0]?.total || 0;

    // Get total orders count
    const totalOrders = await Order.countDocuments();

    // Get total users count
    const totalUsers = await User.countDocuments({ role: 'user' });

    // Get total menu items count
    const totalMenuItems = await MenuItem.countDocuments();

    // Get recent orders (last 5)
    const recentOrders = await Order.find()
      .sort({ createdAt: -1 })
      .limit(5)
      .populate('userId', 'name email');

    // Get popular items (most ordered)
    const popularItems = await Order.aggregate([
      { $match: { status: { $ne: 'cancelled' } } },
      { $unwind: '$items' },
      {
        $group: {
          _id: '$items.itemId',
          name: { $first: '$items.name' },
          totalOrdered: { $sum: '$items.quantity' },
          revenue: { $sum: { $multiply: ['$items.quantity', '$items.price'] } }
        }
      },
      { $sort: { totalOrdered: -1 } },
      { $limit: 5 }
    ]);

    res.json({
      totalRevenue,
      totalOrders,
      totalUsers,
      totalMenuItems,
      recentOrders,
      popularItems
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// GET revenue statistics (admin only)
router.get('/revenue', protect, adminOnly, async (req, res) => {
  try {
    const { period, startDate, endDate } = req.query;
    let matchStage = { status: { $ne: 'cancelled' } };

    // Date filtering
    if (startDate || endDate) {
      matchStage.createdAt = {};
      if (startDate) matchStage.createdAt.$gte = new Date(startDate);
      if (endDate) matchStage.createdAt.$lte = new Date(endDate);
    }

    let groupStage;
    switch (period) {
      case 'daily':
        groupStage = {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' },
            day: { $dayOfMonth: '$createdAt' }
          },
          revenue: { $sum: '$totalAmount' },
          orders: { $sum: 1 }
        };
        break;
      case 'weekly':
        groupStage = {
          _id: {
            year: { $year: '$createdAt' },
            week: { $week: '$createdAt' }
          },
          revenue: { $sum: '$totalAmount' },
          orders: { $sum: 1 }
        };
        break;
      case 'monthly':
        groupStage = {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' }
          },
          revenue: { $sum: '$totalAmount' },
          orders: { $sum: 1 }
        };
        break;
      default:
        groupStage = {
          _id: null,
          revenue: { $sum: '$totalAmount' },
          orders: { $sum: 1 }
        };
    }

    const result = await Order.aggregate([
      { $match: matchStage },
      { $group: groupStage },
      { $sort: { '_id': 1 } }
    ]);

    res.json({ period, data: result });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// GET orders count (admin only)
router.get('/orders/count', protect, adminOnly, async (req, res) => {
  try {
    const { status, period } = req.query;
    let filter = {};

    if (status) {
      filter.status = status;
    }

    // Period filtering
    if (period) {
      const now = new Date();
      switch (period) {
        case 'today':
          filter.createdAt = {
            $gte: new Date(now.getFullYear(), now.getMonth(), now.getDate())
          };
          break;
        case 'week':
          const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          filter.createdAt = { $gte: weekAgo };
          break;
        case 'month':
          filter.createdAt = {
            $gte: new Date(now.getFullYear(), now.getMonth(), 1)
          };
          break;
      }
    }

    const count = await Order.countDocuments(filter);
    res.json({ count, filter: { status, period } });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// GET recent orders (admin only)
router.get('/orders/recent', protect, adminOnly, async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    const orders = await Order.find()
      .sort({ createdAt: -1 })
      .limit(limit)
      .populate('userId', 'name email');

    res.json(orders);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// GET popular menu items (admin only)
router.get('/menu/popular', protect, adminOnly, async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 10;
    
    const popularItems = await Order.aggregate([
      { $match: { status: { $ne: 'cancelled' } } },
      { $unwind: '$items' },
      {
        $group: {
          _id: '$items.itemId',
          name: { $first: '$items.name' },
          totalOrdered: { $sum: '$items.quantity' },
          revenue: { $sum: { $multiply: ['$items.quantity', '$items.price'] } },
          avgPrice: { $avg: '$items.price' }
        }
      },
      { $sort: { totalOrdered: -1 } },
      { $limit: limit }
    ]);

    res.json(popularItems);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// GET users count (admin only)
router.get('/users/count', protect, adminOnly, async (req, res) => {
  try {
    const { role } = req.query;
    const filter = role ? { role } : {};
    const count = await User.countDocuments(filter);
    res.json({ count, filter });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// GET order status distribution (admin only)
router.get('/orders/status-distribution', protect, adminOnly, async (req, res) => {
  try {
    const distribution = await Order.aggregate([
      {
        $group: {
          _id: '$status',
          count: { $sum: 1 },
          revenue: { $sum: '$totalAmount' }
        }
      },
      { $sort: { count: -1 } }
    ]);

    res.json(distribution);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// GET sales trends (admin only)
router.get('/sales/trends', protect, adminOnly, async (req, res) => {
  try {
    const { days = 30 } = req.query;
    const daysAgo = new Date();
    daysAgo.setDate(daysAgo.getDate() - parseInt(days));

    const trends = await Order.aggregate([
      {
        $match: {
          createdAt: { $gte: daysAgo },
          status: { $ne: 'cancelled' }
        }
      },
      {
        $group: {
          _id: {
            year: { $year: '$createdAt' },
            month: { $month: '$createdAt' },
            day: { $dayOfMonth: '$createdAt' }
          },
          revenue: { $sum: '$totalAmount' },
          orders: { $sum: 1 },
          avgOrderValue: { $avg: '$totalAmount' }
        }
      },
      { $sort: { '_id': 1 } }
    ]);

    res.json({ period: `${days} days`, trends });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
