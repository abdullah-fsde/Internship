import express from 'express';
import MenuItem from '../models/MenuItem.js';
import { protect, adminOnly } from '../middleware/auth.js';

const router = express.Router();

// GET all menu items (no auth required)
router.get('/items', async (req, res) => {
  try {
    const { category, featured, available, search, limit, page } = req.query;
    const filter = {};
    
    // Build filter object
    if (category) filter.category = category;
    if (featured !== undefined) filter.featured = featured === 'true';
    if (available !== undefined) filter.available = available === 'true';
    
    // Text search
    if (search) {
      filter.$text = { $search: search };
    }

    // Pagination
    const pageNum = parseInt(page) || 1;
    const limitNum = parseInt(limit) || 0;
    const skip = limitNum > 0 ? (pageNum - 1) * limitNum : 0;

    let query = MenuItem.find(filter);
    
    // Add text search score for sorting
    if (search) {
      query = query.select({ score: { $meta: 'textScore' } });
      query = query.sort({ score: { $meta: 'textScore' } });
    } else {
      query = query.sort({ createdAt: -1 });
    }

    if (limitNum > 0) {
      query = query.skip(skip).limit(limitNum);
    }

    const items = await query;
    
    // Get total count for pagination
    const total = await MenuItem.countDocuments(filter);
    
    res.json({
      items,
      pagination: limitNum > 0 ? {
        page: pageNum,
        limit: limitNum,
        total,
        pages: Math.ceil(total / limitNum)
      } : null
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// GET single menu item (no auth required)
router.get('/items/:id', async (req, res) => {
  try {
    const item = await MenuItem.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'Item not found' });
    res.json(item);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// GET categories (no auth required)
router.get('/categories', (req, res) => {
  const categories = ['Starters', 'Mains', 'Desserts', 'Beverages'];
  res.json(categories);
});

// POST create menu item (admin only)
router.post('/items', protect, adminOnly, async (req, res) => {
  try {
    const item = new MenuItem(req.body);
    await item.save();
    res.status(201).json(item);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// PUT update menu item (admin only)
router.put('/items/:id', protect, adminOnly, async (req, res) => {
  try {
    const item = await MenuItem.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!item) return res.status(404).json({ message: 'Item not found' });
    res.json(item);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

// DELETE menu item (admin only)
router.delete('/items/:id', protect, adminOnly, async (req, res) => {
  try {
    const item = await MenuItem.findByIdAndDelete(req.params.id);
    if (!item) return res.status(404).json({ message: 'Item not found' });
    res.json({ message: 'Item deleted' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// PATCH toggle availability (admin only)
router.patch('/items/:id/availability', protect, adminOnly, async (req, res) => {
  try {
    const item = await MenuItem.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'Item not found' });
    
    item.available = !item.available;
    await item.save();
    res.json(item);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
