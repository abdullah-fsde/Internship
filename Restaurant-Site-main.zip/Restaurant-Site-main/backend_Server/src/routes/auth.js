import express from 'express';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';

const router = express.Router();

const generateToken = (user) => {
  return jwt.sign(
    { id: user._id, email: user.email, role: user.role },
    process.env.JWT_SECRET,
    { expiresIn: '7d' }
  );
};

// Clerk webhook to sync users
router.post('/clerk-webhook', async (req, res) => {
  try {
    const { type, data } = req.body;
    
    if (type === 'user.created') {
      const { id, email_addresses, first_name, last_name, public_metadata } = data;
      
      const email = email_addresses[0]?.email_address;
      const name = `${first_name || ''} ${last_name || ''}`.trim() || 'User';
      const role = public_metadata?.role || (email?.toLowerCase() === 'adminresto@gmail.com' ? 'admin' : 'user');
      
      // Create user in our database
      const user = new User({
        clerkId: id,
        name,
        email,
        role,
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${name}`,
      });
      
      await user.save();
      console.log('User synced from Clerk:', email);
    }
    
    if (type === 'user.updated') {
      const { id, email_addresses, first_name, last_name, public_metadata } = data;
      
      const email = email_addresses[0]?.email_address;
      const name = `${first_name || ''} ${last_name || ''}`.trim() || 'User';
      const role = public_metadata?.role || (email?.toLowerCase() === 'adminresto@gmail.com' ? 'admin' : 'user');
      
      await User.findOneAndUpdate(
        { clerkId: id },
        { name, email, role },
        { upsert: true }
      );
      console.log('User updated from Clerk:', email);
    }
    
    res.status(200).json({ received: true });
  } catch (error) {
    console.error('Clerk webhook error:', error);
    res.status(500).json({ error: error.message });
  }
});

// Get or create user from Clerk token
router.post('/sync-user', async (req, res) => {
  try {
    const { clerkId, email, name, role } = req.body;
    
    if (!clerkId || !email) {
      return res.status(400).json({ message: 'Clerk ID and email required' });
    }
    
    let user = await User.findOne({ clerkId });
    
    if (!user) {
      // Create new user
      user = new User({
        clerkId,
        name: name || 'User',
        email,
        role: role || (email.toLowerCase() === 'adminresto@gmail.com' ? 'admin' : 'user'),
        avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${name || email}`,
      });
      await user.save();
    } else {
      // Update existing user
      user.name = name || user.name;
      user.email = email;
      user.role = role || user.role;
      await user.save();
    }
    
    const token = generateToken(user);
    res.json({
      token,
      user: {
        id: user._id,
        clerkId: user.clerkId,
        name: user.name,
        email: user.email,
        role: user.role,
        avatar: user.avatar,
      },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Verify Clerk user and get backend token
router.post('/verify-clerk', async (req, res) => {
  try {
    const { clerkId } = req.body;
    
    if (!clerkId) {
      return res.status(400).json({ message: 'Clerk ID required' });
    }
    
    const user = await User.findOne({ clerkId });
    
    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    const token = generateToken(user);
    res.json({
      token,
      user: {
        id: user._id,
        clerkId: user.clerkId,
        name: user.name,
        email: user.email,
        role: user.role,
        avatar: user.avatar,
      },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Legacy endpoints for backward compatibility
router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ message: 'All fields required' });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    const user = new User({ name, email, password, role: 'user' });
    await user.save();

    const token = generateToken(user);
    res.status(201).json({
      token,
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password required' });
    }

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const isPasswordValid = await user.comparePassword(password);
    if (!isPasswordValid) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const token = generateToken(user);
    res.json({
      token,
      user: { id: user._id, name: user.name, email: user.email, role: user.role },
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

export default router;
