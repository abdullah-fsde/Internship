# 🍽️ Restaurant Management System

A complete full-stack restaurant management system with user ordering and admin dashboard functionality.

## 🚀 Quick Start

### Prerequisites
- Node.js (v16 or higher)
- MongoDB (local or cloud)
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd Restaurant-Site
   ```

2. **Setup Backend**
   ```bash
   cd backend_Server
   npm install
   cp .env.example .env
   # Edit .env with your MongoDB connection string
   npm start
   ```

3. **Setup Database**
   ```bash
   cd database-seeder
   npm install
   cp .env.example .env
   # Edit .env with your MongoDB connection string
   node seed.js
   ```

4. **Setup Frontend**
   ```bash
   cd restaurant-hub-main
   npm install
   cp .env.example .env
   # No editing needed - uses localhost:5000 by default
   npm run dev
   ```

5. **Access the Application**
   - **Frontend**: http://localhost:8080
   - **Backend API**: http://localhost:5000
   - **API Documentation**: http://localhost:5000/api

## 🔑 Test Credentials

### Admin Access
```
Email: admin@restaurant.com
Password: admin123
Features: Full admin dashboard access
```

### User Access
```
Email: sarah@example.com
Password: user123
Features: Menu browsing, ordering, profile

Email: user@restaurant.com
Password: user123
Features: Menu browsing, ordering, profile
```

## 🎯 Features

### 👤 User Features
- **Authentication**: Email/password login and registration
- **Menu Browsing**: View 27+ menu items across 4 categories
- **Shopping Cart**: Add items, update quantities, remove items
- **Order Placement**: Complete checkout with delivery details
- **Profile Management**: View and edit profile information
- **Order History**: Track order status and history

### 🛡️ Admin Features
- **Dashboard**: Real-time statistics and analytics
- **Menu Management**: Full CRUD operations on menu items
  - Add new items with auto-image suggestions
  - Edit existing items with price conversion
  - Toggle availability on/off
  - Delete items with confirmation
- **Order Management**: View and update order statuses
- **User Management**: View all registered users
- **Revenue Tracking**: Real-time revenue calculations

## 🏗️ Architecture

### Frontend (React + TypeScript)
- **Framework**: React 18 with TypeScript
- **Styling**: Tailwind CSS + shadcn/ui components
- **State Management**: React Context API
- **Routing**: React Router v6
- **HTTP Client**: Fetch API with custom service layer

### Backend (Node.js + Express)
- **Framework**: Express.js
- **Database**: MongoDB with Mongoose ODM
- **Authentication**: JWT tokens
- **API**: RESTful API with comprehensive endpoints
- **Middleware**: CORS, body parsing, authentication

### Database (MongoDB)
- **Collections**: users, menuitems, orders
- **Indexes**: Optimized for performance
- **Seeding**: Automated with realistic test data

## 📁 Project Structure

```
Restaurant-Site/
├── backend_Server/          # Express.js backend
│   ├── src/
│   │   ├── config/         # Database configuration
│   │   ├── middleware/     # Auth middleware
│   │   ├── models/         # Mongoose models
│   │   ├── routes/         # API routes
│   │   └── server.js       # Main server file
│   └── package.json
├── database-seeder/         # Database seeding utility
│   ├── seed.js             # Seed script with test data
│   └── package.json
├── restaurant-hub-main/     # React frontend
│   ├── src/
│   │   ├── components/     # Reusable components
│   │   ├── context/        # React contexts
│   │   ├── pages/          # Page components
│   │   ├── services/       # API service layer
│   │   └── App.tsx         # Main app component
│   └── package.json
└── README.md
```

## 🔧 Configuration

### Backend Environment Variables (.env)
```env
MONGODB_URI=mongodb://localhost:27017/restaurant
JWT_SECRET=your-secret-key-here
PORT=5000
NODE_ENV=development
```

### Frontend Environment Variables (.env)
```env
VITE_API_BASE_URL=http://localhost:5000/api
```

### Database Seeder Environment Variables (.env)
```env
MONGODB_URI=mongodb://localhost:27017/restaurant
```

## 🧪 Testing

### Manual Testing
1. **User Flow**:
   - Register/Login → Browse Menu → Add to Cart → Checkout → View Orders

2. **Admin Flow**:
   - Admin Login → Dashboard → Manage Menu → Manage Orders → View Users

### API Testing
```bash
# Health check
curl http://localhost:5000/api/health

# Login
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@restaurant.com","password":"admin123"}'

# Get menu items
curl http://localhost:5000/api/menu/items
```

## 📊 Database Content

### Sample Data Included
- **Users**: 11 total (2 admins, 9 customers)
- **Menu Items**: 27 items across 4 categories
- **Orders**: 10 sample orders with various statuses

### Categories
- **Starters**: 7 items (₹9.50 - ₹22.00)
- **Mains**: 8 items (₹25.00 - ₹45.00)
- **Desserts**: 6 items (₹6.50 - ₹9.50)
- **Beverages**: 6 items (₹3.00 - ₹18.00)

## 🔐 Authentication & Security

- **JWT Tokens**: 7-day expiration, stored in localStorage
- **Password Hashing**: bcrypt with salt rounds
- **Role-Based Access**: Admin/user role separation
- **Protected Routes**: Authentication required for sensitive operations
- **Input Validation**: Server-side validation for all inputs

## 🚀 Deployment

### Backend Deployment
1. Set production environment variables
2. Ensure MongoDB connection is configured
3. Run `npm start` or use PM2 for process management

### Frontend Deployment
1. Update `VITE_API_BASE_URL` to production backend URL
2. Run `npm run build`
3. Serve the `dist` folder using a web server

### Database Setup
1. Create MongoDB database
2. Run the seeder: `node database-seeder/seed.js`
3. Verify collections and indexes are created

## 🛠️ Development

### Running in Development
```bash
# Terminal 1 - Backend
cd backend_Server && npm run dev

# Terminal 2 - Frontend  
cd restaurant-hub-main && npm run dev

# Terminal 3 - Database seeding (if needed)
cd database-seeder && node seed.js
```

### Adding New Features
1. **Backend**: Add routes in `backend_Server/src/routes/`
2. **Frontend**: Add components in `restaurant-hub-main/src/`
3. **Database**: Update models in `backend_Server/src/models/`

## 📝 API Documentation

### Authentication Endpoints
- `POST /api/auth/login` - User login
- `POST /api/auth/register` - User registration

### Menu Endpoints
- `GET /api/menu/items` - Get all menu items
- `POST /api/menu/items` - Create menu item (admin)
- `PUT /api/menu/items/:id` - Update menu item (admin)
- `DELETE /api/menu/items/:id` - Delete menu item (admin)

### Order Endpoints
- `POST /api/orders` - Create order (auth required)
- `GET /api/orders` - Get orders (user: own, admin: all)
- `PATCH /api/orders/:id/status` - Update order status (admin)

### User Endpoints
- `GET /api/users` - Get all users (admin)
- `GET /api/users/:id` - Get user profile
- `PUT /api/users/:id` - Update user profile

### Statistics Endpoints (Admin Only)
- `GET /api/stats/overview` - Dashboard statistics
- `GET /api/stats/revenue` - Revenue analytics
- `GET /api/stats/orders/recent` - Recent orders

## 🐛 Troubleshooting

### Common Issues

1. **MongoDB Connection Error**
   - Check MongoDB is running
   - Verify connection string in .env files

2. **Port Already in Use**
   - Backend: Change PORT in backend_Server/.env
   - Frontend: Change port in vite.config.js

3. **CORS Issues**
   - Ensure backend CORS is configured for frontend URL

4. **Authentication Issues**
   - Clear localStorage and try logging in again
   - Check JWT_SECRET is set in backend .env

### Logs and Debugging
- Backend logs: Check terminal running `npm start`
- Frontend logs: Check browser developer console
- Database logs: Check MongoDB logs

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License.

## 🆘 Support

For issues and questions:
1. Check the troubleshooting section
2. Review the API documentation
3. Check browser console for frontend issues
4. Check server logs for backend issues

---

**Built with ❤️ using React, Node.js, and MongoDB**