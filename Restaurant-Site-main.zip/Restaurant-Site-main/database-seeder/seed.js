import mongoose from 'mongoose';
import dotenv from 'dotenv';
import bcryptjs from 'bcryptjs';

dotenv.config();

// Fixed collection names - simple names
const COLLECTION_NAMES = {
  users: 'users',
  menuItems: 'menuitems',
  orders: 'orders',
};

console.log(`\n📊 Using Collections:`);
console.log(`   • ${COLLECTION_NAMES.users}`);
console.log(`   • ${COLLECTION_NAMES.menuItems}`);
console.log(`   • ${COLLECTION_NAMES.orders}\n`);

// Define schemas inline for seeding
const userSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,
  role: { type: String, enum: ['user', 'admin'], default: 'user' },
  avatar: String,
}, { timestamps: true });

const menuItemSchema = new mongoose.Schema({
  name: String,
  description: String,
  price: Number,
  category: { type: String, enum: ['Starters', 'Mains', 'Desserts', 'Beverages'] },
  image: String,
  available: Boolean,
  featured: Boolean,
}, { timestamps: true });

const orderSchema = new mongoose.Schema({
  userId: mongoose.Schema.Types.ObjectId,
  customerName: String,
  customerEmail: String,
  customerPhone: String,
  deliveryAddress: {
    street: String,
    city: String,
    zip: String,
  },
  items: [{
    itemId: mongoose.Schema.Types.ObjectId,
    name: String,
    quantity: Number,
    price: Number,
  }],
  totalAmount: Number,
  status: { type: String, enum: ['pending', 'preparing', 'ready', 'delivered', 'cancelled'] },
}, { timestamps: true });

// Create models with fixed collection names
const User = mongoose.model('User', userSchema, COLLECTION_NAMES.users);
const MenuItem = mongoose.model('MenuItem', menuItemSchema, COLLECTION_NAMES.menuItems);
const Order = mongoose.model('Order', orderSchema, COLLECTION_NAMES.orders);

// Prepare database - create indexes and collections
const prepareDatabase = async () => {
  try {
    console.log('🔧 Preparing database for use...\n');

    // Create indexes for better query performance
    console.log('📑 Creating indexes...');
    
    // User indexes
    await User.collection.createIndex({ email: 1 }, { unique: true });
    console.log('   ✓ User email index (unique)');
    
    await User.collection.createIndex({ role: 1 });
    console.log('   ✓ User role index');
    
    await User.collection.createIndex({ createdAt: -1 });
    console.log('   ✓ User createdAt index');

    // MenuItem indexes
    await MenuItem.collection.createIndex({ category: 1 });
    console.log('   ✓ MenuItem category index');
    
    await MenuItem.collection.createIndex({ featured: 1 });
    console.log('   ✓ MenuItem featured index');
    
    await MenuItem.collection.createIndex({ available: 1 });
    console.log('   ✓ MenuItem available index');
    
    await MenuItem.collection.createIndex({ name: 'text', description: 'text' });
    console.log('   ✓ MenuItem text search index');

    // Order indexes
    await Order.collection.createIndex({ userId: 1 });
    console.log('   ✓ Order userId index');
    
    await Order.collection.createIndex({ status: 1 });
    console.log('   ✓ Order status index');
    
    await Order.collection.createIndex({ createdAt: -1 });
    console.log('   ✓ Order createdAt index');
    
    await Order.collection.createIndex({ 'deliveryAddress.city': 1 });
    console.log('   ✓ Order city index\n');

    console.log('✅ Database prepared successfully!\n');
  } catch (error) {
    console.error('❌ Error preparing database:', error.message);
    throw error;
  }
};

const seedDatabase = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✓ Connected to MongoDB');
    console.log(`✓ Database: ${mongoose.connection.name}\n`);

    // Step 1: Prepare database (create indexes and collections)
    await prepareDatabase();

    // Step 2: Clear existing data from collections
    console.log('🗑️  Clearing existing data...\n');
    await User.deleteMany({});
    await MenuItem.deleteMany({});
    await Order.deleteMany({});
    console.log('✓ Cleared existing data\n');

    // Hash passwords
    const adminPassword = await bcryptjs.hash('admin123', 10);
    const userPassword = await bcryptjs.hash('user123', 10);

    // Step 3: Seed users - Enhanced with Clerk integration support
    console.log('👥 Seeding users...');
    const users = await User.insertMany([
      // Admin user - with Clerk support
      {
        name: 'Admin User',
        email: 'adminresto@gmail.com', // Matches Clerk admin email check
        password: adminPassword,
        role: 'admin',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=admin',
        clerkId: null, // Will be set when admin signs up via Clerk
      },
      
      // Legacy admin for testing
      {
        name: 'Legacy Admin',
        email: 'admin@restaurant.com',
        password: adminPassword,
        role: 'admin',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=legacyadmin',
      },
      
      // Regular users (matching frontend mock data)
      {
        name: 'John Doe',
        email: 'user@restaurant.com',
        password: userPassword,
        role: 'user',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=john',
        clerkId: null, // Will be set when user signs up via Clerk
      },
      {
        name: 'Sarah Smith',
        email: 'sarah@example.com',
        password: userPassword,
        role: 'user',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sarah',
      },
      {
        name: 'Mike Johnson',
        email: 'mike@example.com',
        password: userPassword,
        role: 'user',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=mike',
      },
      
      // Additional users for realistic admin dashboard
      {
        name: 'Emily Davis',
        email: 'emily@example.com',
        password: userPassword,
        role: 'user',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=emily',
      },
      {
        name: 'David Wilson',
        email: 'david@example.com',
        password: userPassword,
        role: 'user',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=david',
      },
      {
        name: 'Lisa Anderson',
        email: 'lisa@example.com',
        password: userPassword,
        role: 'user',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=lisa',
      },
      {
        name: 'Robert Taylor',
        email: 'robert@example.com',
        password: userPassword,
        role: 'user',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=robert',
      },
      {
        name: 'Jennifer Brown',
        email: 'jennifer@example.com',
        password: userPassword,
        role: 'user',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=jennifer',
      },
      {
        name: 'Michael Garcia',
        email: 'michael@example.com',
        password: userPassword,
        role: 'user',
        avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=michael',
      },
    ]);
    console.log(`✓ ${users.length} users seeded\n`);

    // Step 4: Seed menu items - Enhanced to match frontend requirements exactly
    console.log('🍽️  Seeding menu items...');
    const menuItems = await MenuItem.insertMany([
      // Starters (7 items)
      {
        name: 'Beef Carpaccio',
        description: 'Thinly sliced raw beef with arugula, capers, and truffle aioli',
        price: 1800,
        category: 'Starters',
        image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
      {
        name: 'Lobster Bisque',
        description: 'Rich and creamy lobster soup with brandy and fresh cream',
        price: 1400,
        category: 'Starters',
        image: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?w=500&h=500&fit=crop',
        available: true,
        featured: true,
      },
      {
        name: 'Caesar Salad',
        description: 'Crisp romaine, house-made dressing, parmesan, and garlic croutons',
        price: 1200,
        category: 'Starters',
        image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
      {
        name: 'Bruschetta al Pomodoro',
        description: 'Toasted bread with fresh tomato, garlic, basil, and olive oil',
        price: 950,
        category: 'Starters',
        image: 'https://images.unsplash.com/photo-1541519227354-08fa5d50c44d?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
      {
        name: 'Calamari Fritti',
        description: 'Crispy fried squid served with lemon and marinara sauce',
        price: 1100,
        category: 'Starters',
        image: 'https://images.unsplash.com/photo-1599810694-b5ac4dd64b73?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
      {
        name: 'Burrata Caprese',
        description: 'Creamy burrata with heirloom tomatoes, basil, and balsamic glaze',
        price: 1600,
        category: 'Starters',
        image: 'https://images.unsplash.com/photo-1608897013039-887f21d8c804?w=500&h=500&fit=crop',
        available: true,
        featured: true,
      },
      {
        name: 'Oysters Rockefeller',
        description: 'Fresh oysters baked with spinach, herbs, and hollandaise',
        price: 2200,
        category: 'Starters',
        image: 'https://images.unsplash.com/photo-1606756790138-261d2b21cd75?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },

      // Mains (8 items) - Matching frontend mock data exactly
      {
        name: 'Truffle Risotto',
        description: 'Creamy Arborio rice with black truffle, aged parmesan, and fresh herbs',
        price: 2500,
        category: 'Mains',
        image: 'https://images.unsplash.com/photo-1476124369162-f4978d1a23e2?w=500&h=500&fit=crop',
        available: true,
        featured: true,
      },
      {
        name: 'Seared Scallops',
        description: 'Pan-seared sea scallops with cauliflower purée and brown butter',
        price: 3000,
        category: 'Mains',
        image: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=500&h=500&fit=crop',
        available: true,
        featured: true,
      },
      {
        name: 'Grilled Salmon',
        description: 'Atlantic salmon with lemon herb butter and seasonal vegetables',
        price: 2700,
        category: 'Mains',
        image: 'https://images.unsplash.com/photo-1467003909585-2f8a72700288?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
      {
        name: 'Duck Confit',
        description: 'Slow-cooked duck leg with cherry reduction and roasted potatoes',
        price: 2800,
        category: 'Mains',
        image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=500&h=500&fit=crop',
        available: false, // Matches frontend mock data
        featured: false,
      },
      {
        name: 'Beef Wellington',
        description: 'Prime beef tenderloin wrapped in puff pastry with mushroom duxelles',
        price: 4200,
        category: 'Mains',
        image: 'https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=500&h=500&fit=crop',
        available: true,
        featured: true,
      },
      {
        name: 'Osso Buco',
        description: 'Braised veal shanks with saffron risotto and gremolata',
        price: 3800,
        category: 'Mains',
        image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
      {
        name: 'Lobster Thermidor',
        description: 'Whole lobster with cognac cream sauce and gruyere cheese',
        price: 4500,
        category: 'Mains',
        image: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=500&h=500&fit=crop',
        available: true,
        featured: true,
      },
      {
        name: 'Rack of Lamb',
        description: 'Herb-crusted lamb with rosemary jus and roasted vegetables',
        price: 3600,
        category: 'Mains',
        image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },

      // Desserts (6 items) - Matching frontend exactly
      {
        name: 'Chocolate Fondant',
        description: 'Warm chocolate cake with molten center, served with vanilla ice cream',
        price: 900,
        category: 'Desserts',
        image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=500&h=500&fit=crop',
        available: true,
        featured: true,
      },
      {
        name: 'Crème Brûlée',
        description: 'Classic vanilla custard with caramelized sugar crust',
        price: 800,
        category: 'Desserts',
        image: 'https://images.unsplash.com/photo-1470521598063-6f3ee1c9a3a8?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
      {
        name: 'Tiramisu',
        description: 'Traditional Italian dessert with espresso-soaked ladyfingers',
        price: 950,
        category: 'Desserts',
        image: 'https://images.unsplash.com/photo-1571115177098-24ec42ed204d?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
      {
        name: 'Lemon Tart',
        description: 'Buttery pastry shell filled with tangy lemon curd and meringue',
        price: 750,
        category: 'Desserts',
        image: 'https://images.unsplash.com/photo-1519915028121-7d3463d20b13?w=500&h=500&fit=crop',
        available: true,
        featured: true,
      },
      {
        name: 'Panna Cotta',
        description: 'Silky vanilla custard with seasonal berry compote',
        price: 700,
        category: 'Desserts',
        image: 'https://images.unsplash.com/photo-1488477181946-6428a0291840?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
      {
        name: 'Affogato',
        description: 'Vanilla gelato "drowned" in hot espresso with amaretti',
        price: 650,
        category: 'Desserts',
        image: 'https://images.unsplash.com/photo-1551024506-0bccd828d307?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },

      // Beverages (6 items) - Matching frontend exactly
      {
        name: 'House Red Wine',
        description: 'Smooth Cabernet Sauvignon from Napa Valley',
        price: 900,
        category: 'Beverages',
        image: 'https://images.unsplash.com/photo-1510812431401-41d2cab2707d?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
      {
        name: 'Sparkling Water',
        description: 'Premium Italian sparkling mineral water',
        price: 400,
        category: 'Beverages',
        image: 'https://images.unsplash.com/photo-1544145945-f90425340c7e?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
      {
        name: 'Espresso',
        description: 'Rich Italian espresso shot',
        price: 300,
        category: 'Beverages',
        image: 'https://images.unsplash.com/photo-1559056199-641a0ac8b3f4?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
      {
        name: 'Cappuccino',
        description: 'Espresso with steamed milk and velvety foam',
        price: 450,
        category: 'Beverages',
        image: 'https://images.unsplash.com/photo-1517668808822-9ebb02ae2a0e?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
      {
        name: 'Champagne Brut',
        description: 'Premium French champagne, crisp and elegant',
        price: 1800,
        category: 'Beverages',
        image: 'https://images.unsplash.com/photo-1510812431401-41d2cab2707d?w=500&h=500&fit=crop',
        available: true,
        featured: true,
      },
      {
        name: 'Craft Cocktail',
        description: 'Signature cocktail with premium spirits and fresh ingredients',
        price: 1200,
        category: 'Beverages',
        image: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=500&h=500&fit=crop',
        available: true,
        featured: false,
      },
    ]);
    console.log(`✓ ${menuItems.length} menu items seeded\n`);

    // Step 5: Seed comprehensive sample orders - Enhanced for frontend integration
    console.log('📦 Seeding sample orders...');
    const orders = await Order.insertMany([
      // Order 1 - Delivered (matches frontend mock data structure)
      {
        userId: users[1]._id, // John Doe
        customerName: 'John Doe',
        customerEmail: 'user@restaurant.com',
        customerPhone: '9876543210',
        deliveryAddress: {
          street: '123 Main Street',
          city: 'New York',
          zip: '10001',
        },
        items: [
          {
            itemId: menuItems[7]._id, // Truffle Risotto
            name: 'Truffle Risotto',
            quantity: 2,
            price: 2500,
          },
          {
            itemId: menuItems[16]._id, // Chocolate Fondant
            name: 'Chocolate Fondant',
            quantity: 1,
            price: 900,
          },
        ],
        totalAmount: 5900, // (2500 * 2) + 900 = 5900
        status: 'delivered',
      },
      
      // Order 2 - Preparing (matches frontend expectations)
      {
        userId: users[2]._id, // Sarah Smith
        customerName: 'Sarah Smith',
        customerEmail: 'sarah@example.com',
        customerPhone: '9876543211',
        deliveryAddress: {
          street: '456 Oak Avenue',
          city: 'Los Angeles',
          zip: '90001',
        },
        items: [
          {
            itemId: menuItems[8]._id, // Seared Scallops
            name: 'Seared Scallops',
            quantity: 1,
            price: 3000,
          },
          {
            itemId: menuItems[1]._id, // Lobster Bisque
            name: 'Lobster Bisque',
            quantity: 1,
            price: 1400,
          },
        ],
        totalAmount: 4400, // 3000 + 1400 = 4400
        status: 'preparing',
      },

      // Order 3 - Pending
      {
        userId: users[3]._id, // Mike Johnson
        customerName: 'Mike Johnson',
        customerEmail: 'mike@example.com',
        customerPhone: '9876543212',
        deliveryAddress: {
          street: '789 Pine Road',
          city: 'Chicago',
          zip: '60601',
        },
        items: [
          {
            itemId: menuItems[9]._id, // Grilled Salmon
            name: 'Grilled Salmon',
            quantity: 1,
            price: 2700,
          },
          {
            itemId: menuItems[17]._id, // Crème Brûlée
            name: 'Crème Brûlée',
            quantity: 2,
            price: 800,
          },
        ],
        totalAmount: 4300, // 2700 + (800 * 2) = 4300
        status: 'pending',
      },

      // Order 4 - Ready
      {
        userId: users[1]._id, // John Doe (repeat customer)
        customerName: 'John Doe',
        customerEmail: 'user@restaurant.com',
        customerPhone: '9876543210',
        deliveryAddress: {
          street: '123 Main Street',
          city: 'New York',
          zip: '10001',
        },
        items: [
          {
            itemId: menuItems[0]._id, // Beef Carpaccio
            name: 'Beef Carpaccio',
            quantity: 1,
            price: 1800,
          },
          {
            itemId: menuItems[12]._id, // Beef Wellington
            name: 'Beef Wellington',
            quantity: 1,
            price: 4200,
          },
          {
            itemId: menuItems[24]._id, // Champagne Brut
            name: 'Champagne Brut',
            quantity: 1,
            price: 1800,
          },
        ],
        totalAmount: 7800, // 1800 + 4200 + 1800 = 7800
        status: 'ready',
      },

      // Order 5 - Recent pending order
      {
        userId: users[2]._id, // Sarah Smith (repeat customer)
        customerName: 'Sarah Smith',
        customerEmail: 'sarah@example.com',
        customerPhone: '9876543211',
        deliveryAddress: {
          street: '456 Oak Avenue',
          city: 'Los Angeles',
          zip: '90001',
        },
        items: [
          {
            itemId: menuItems[14]._id, // Lobster Thermidor
            name: 'Lobster Thermidor',
            quantity: 1,
            price: 4500,
          },
          {
            itemId: menuItems[19]._id, // Lemon Tart
            name: 'Lemon Tart',
            quantity: 2,
            price: 750,
          },
          {
            itemId: menuItems[25]._id, // Craft Cocktail
            name: 'Craft Cocktail',
            quantity: 2,
            price: 1200,
          },
        ],
        totalAmount: 8400, // 4500 + (750 * 2) + (1200 * 2) = 8400
        status: 'pending',
      },

      // Order 6 - Cancelled order for testing
      {
        userId: users[3]._id, // Mike Johnson
        customerName: 'Mike Johnson',
        customerEmail: 'mike@example.com',
        customerPhone: '9876543212',
        deliveryAddress: {
          street: '789 Pine Road',
          city: 'Chicago',
          zip: '60601',
        },
        items: [
          {
            itemId: menuItems[6]._id, // Oysters Rockefeller
            name: 'Oysters Rockefeller',
            quantity: 2,
            price: 2200,
          },
        ],
        totalAmount: 4400, // 2200 * 2 = 4400
        status: 'cancelled',
      },

      // Order 7 - Large family order
      {
        userId: users[1]._id, // John Doe
        customerName: 'John Doe',
        customerEmail: 'user@restaurant.com',
        customerPhone: '9876543210',
        deliveryAddress: {
          street: '123 Main Street',
          city: 'New York',
          zip: '10001',
        },
        items: [
          {
            itemId: menuItems[7]._id, // Truffle Risotto
            name: 'Truffle Risotto',
            quantity: 3,
            price: 2500,
          },
          {
            itemId: menuItems[8]._id, // Seared Scallops
            name: 'Seared Scallops',
            quantity: 2,
            price: 3000,
          },
          {
            itemId: menuItems[16]._id, // Chocolate Fondant
            name: 'Chocolate Fondant',
            quantity: 3,
            price: 900,
          },
          {
            itemId: menuItems[22]._id, // House Red Wine
            name: 'House Red Wine',
            quantity: 2,
            price: 900,
          },
        ],
        totalAmount: 16200, // (2500*3) + (3000*2) + (900*3) + (900*2) = 16200
        status: 'delivered',
      },

      // Order 8 - Recent order for dashboard
      {
        userId: users[2]._id, // Sarah Smith
        customerName: 'Sarah Smith',
        customerEmail: 'sarah@example.com',
        customerPhone: '9876543211',
        deliveryAddress: {
          street: '456 Oak Avenue',
          city: 'Los Angeles',
          zip: '90001',
        },
        items: [
          {
            itemId: menuItems[13]._id, // Osso Buco
            name: 'Osso Buco',
            quantity: 1,
            price: 3800,
          },
          {
            itemId: menuItems[5]._id, // Burrata Caprese
            name: 'Burrata Caprese',
            quantity: 1,
            price: 1600,
          },
        ],
        totalAmount: 5400, // 3800 + 1600 = 5400
        status: 'preparing',
      },
    ]);
    console.log(`✓ ${orders.length} sample orders seeded\n`);

    console.log('✅ Database seeding completed successfully!\n');
    console.log('📊 Collections:');
    console.log(`   • ${COLLECTION_NAMES.users}`);
    console.log(`   • ${COLLECTION_NAMES.menuItems}`);
    console.log(`   • ${COLLECTION_NAMES.orders}\n`);
    console.log('📈 Data Summary:');
    console.log(`   • Users: ${users.length} (2 admins, ${users.length - 2} customers)`);
    console.log(`   • Menu Items: ${menuItems.length} (7 starters, 8 mains, 6 desserts, 6 beverages)`);
    console.log(`   • Featured Items: ${menuItems.filter(item => item.featured).length}`);
    console.log(`   • Orders: ${orders.length} (various statuses for testing)`);
    console.log(`   • Total Revenue: ₹${orders.filter(o => o.status !== 'cancelled').reduce((sum, o) => sum + o.totalAmount, 0) / 100}`);
    console.log('\n🎯 Frontend Integration Ready:');
    console.log('   • All menu items match frontend mock data structure');
    console.log('   • Order statuses: pending, preparing, ready, delivered, cancelled');
    console.log('   • Categories: Starters, Mains, Desserts, Beverages');
    console.log('   • Featured items for homepage display');
    console.log('   • Realistic pricing in paise (₹25.00 = 2500 paise)');
    console.log('   • High-quality food images from Unsplash');
    console.log('   • Clerk integration support with clerkId field');
    console.log('\n🔑 Test Credentials:');
    console.log('   Clerk Admin: adminresto@gmail.com (sign up via Clerk)');
    console.log('   Legacy Admin: admin@restaurant.com / admin123');
    console.log('   Legacy User: user@restaurant.com / user123');
    console.log('   User: sarah@example.com / user123');
    console.log('   User: mike@example.com / user123');
    console.log('\n✨ Database is ready for Clerk + Backend integration!\n');

    process.exit(0);
  } catch (error) {
    console.error('❌ Error seeding database:', error.message);
    process.exit(1);
  }
};

seedDatabase();
